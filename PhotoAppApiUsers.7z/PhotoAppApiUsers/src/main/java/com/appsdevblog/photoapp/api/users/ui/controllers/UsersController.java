package com.appsdevblog.photoapp.api.users.ui.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.deser.std.StringArrayDeserializer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

@RestController
@RequestMapping("/users")
public class UsersController {

	@Autowired
	private Environment env;

	@GetMapping("/status/check")
	public String status() {
		String s = "Working: ";

		return s + env.getProperty("local.server.port");

	}
	
}
